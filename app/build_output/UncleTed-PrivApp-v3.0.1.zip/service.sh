#!/system/bin/sh
MODDIR=${0%/*}

# Wait until device fully completes boot
until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 3
done
sleep 2

APK_PATH="$MODDIR/system/priv-app/UncleTed/UncleTed.apk"

# Ensure APK is indexed and available in user space
if [ -f "$APK_PATH" ]; then
    CURRENT_PATH=$(pm path com.hamoon.uncleted 2>/dev/null)
    if [ -z "$CURRENT_PATH" ] || echo "$CURRENT_PATH" | grep -q "/system/priv-app"; then
        pm install -r -d -g "$APK_PATH" >/dev/null 2>&1 || pm install -r -d "$APK_PATH" >/dev/null 2>&1
    fi
fi

# KernelSU / KernelSU-Next CLI Profile Enforcement
if command -v ksud >/dev/null 2>&1; then
    ksud profile set com.hamoon.uncleted --allow-su >/dev/null 2>&1 || true
    ksud profile set com.hamoon.uncleted allow.su true >/dev/null 2>&1 || true
fi

# Ensure platform credentials directory is armed
mkdir -p /data/system/uncleted
chmod 0755 /data/system/uncleted
chown 1000:1000 /data/system/uncleted
chcon u:object_r:system_data_file:s0 /data/system/uncleted 2>/dev/null || true
