#!/sbin/sh
##########################################################################################
# Uncle Ted Systemless Priv-App Installer
##########################################################################################

ui_print "***********************************************"
ui_print "       Uncle Ted System Defense Suite          "
ui_print "    Priv-App Overlay & Platform Integrator     "
ui_print "***********************************************"

# Set standard directory and file permissions
ui_print "- Applying SELinux contexts and POSIX permissions..."
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
set_perm "$MODPATH/system/priv-app/UncleTed" 0 0 0755
set_perm "$MODPATH/system/priv-app/UncleTed/UncleTed.apk" 0 0 0644
set_perm "$MODPATH/system/etc/permissions" 0 0 0755
set_perm "$MODPATH/system/etc/permissions/privapp-permissions-uncleted.xml" 0 0 0644
chcon -R u:object_r:system_file:s0 "$MODPATH/system"

# Crucial Out-of-the-Box KernelSU / Magisk Fix:
# In KernelSU, apps are isolated and module mounts are stripped by default in user namespaces.
# Installing the APK directly ensures LoadedApk always resolves assets without relying on
# isolated /system/priv-app mount namespaces.
if [ "$BOOTMODE" = "true" ]; then
    ui_print "- Installing Uncle Ted into package database (Dual-Install)..."
    APK_SRC="$MODPATH/system/priv-app/UncleTed/UncleTed.apk"
    if [ -f "$APK_SRC" ]; then
        pm install -r -d -g "$APK_SRC" >/dev/null 2>&1 || pm install -r -d "$APK_SRC" >/dev/null 2>&1
    fi

    # Automatically configure KernelSU App Profile if ksud is available
    if command -v ksud >/dev/null 2>&1; then
        ui_print "- Configuring KernelSU superuser profile..."
        ksud profile set com.hamoon.uncleted --allow-su >/dev/null 2>&1 || true
        ksud profile set com.hamoon.uncleted allow.su true >/dev/null 2>&1 || true
    fi
fi

# Ensure credentials bridge directory exists with proper SELinux context
mkdir -p /data/system/uncleted
chmod 0755 /data/system/uncleted
chown 1000:1000 /data/system/uncleted
chcon u:object_r:system_data_file:s0 /data/system/uncleted 2>/dev/null || true

ui_print " "
ui_print "✓ Installation successful!"
ui_print "✓ Enable 'UncleTed' in LSPosed Manager and reboot to complete setup."
